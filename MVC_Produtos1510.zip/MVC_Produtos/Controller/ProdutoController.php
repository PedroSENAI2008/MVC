<?php
require_once 'C:/xampp/htdocs/MVC_Produtos/Model/ProdutoModel.php';

class ProdutoController{
    private $ProdutoModel;

public function __construct ($pdo){
    $this->ProdutoModel = new ProdutoModel($pdo);
}
 public function listar() {
        $produtos = $this->ProdutoModel->buscarTodos();
        include_once "C:/xampp/htdocs/MVC_Produtos/View/Produto/listar.php";
        return $produtos;
    }
    public function buscarProduto($id){
        $produto = $this->ProdutoModel->buscarProduto($id);
        return $produto;

    }

 public function cadastrar($nome, $descri, $quant, $code, $preco){
    return $this->ProdutoModel->cadastrar($nome, $descri, $quant, $code, $preco);
}

public function deletar($id){
    $produto = $this->ProdutoModel->deletar($id);

}

public function editar($id, $nome, $descri, $quant, $code, $preco){
    return $this->ProdutoModel->editar($id, $nome, $descri, $quant, $code, $preco);
}
}
?>
