<?php
require_once 'DB/Database.php';
require_once 'Controller/PayController.php';

$PayController = new PayController($pdo);
$pay= $PayController->listar();
?>