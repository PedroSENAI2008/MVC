<?php
require_once 'C:/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/xampp/htdocs/MVC_Produtos/Controller/ProdutoController.php';
$ProdutoController = new ProdutoController($pdo);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome= $_POST['nome'];
    $descri= $_POST['descri'];
    $quant= $_POST['quant'];
    $code= $_POST['code'];
    $preco= $_POST['preco'];
    


    $ProdutoController->cadastrar($nome, $descri,$quant,$code, $preco);
    header('Location: ../../index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    
    <form method="POST">
        <h1>Cadastre-se</h1>
        <input type="text" name="nome" placeholder="Nome" required><br>
        <input type="text" name="descri" placeholder="Descrição" required><br>
        <input type="number" name="quant" placeholder="Quantidade" required><br>
        <input type="number" name="code" placeholder="Código de Barra" required><br>
        <input type="number" name="preco" placeholder="Preço" required><br>


        <button type="submit">Cadastrar</button>

</form>
</body>
</html>

