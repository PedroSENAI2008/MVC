<?php
require_once 'C:/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/xampp/htdocs/MVC_Produtos/Controller/PayController.php';
$PayController = new PayController($pdo);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome= $_POST['nome'];
    $tipo= $_POST['tipo'];


    $PayController->cadastrarPay($nome, $tipo);
    header('Location: ../../pagamento.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    
    <form method="POST">
        <h1>Cadastre-se</h1>
        <input type="text" name="nome" placeholder="Nome" required><br>
        <input type="text" name="tipo" placeholder="tipo" required><br>


        <button type="submit">Cadastrar</button>

</form>
</body>
</html>

