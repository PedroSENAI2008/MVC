<?php
require_once 'DB/Database.php';
require_once 'Controller/ProdutoController.php';
require_once 'Controller/PayController.php';

$ProdutoController = new ProdutoController($pdo);
$produto= $ProdutoController->listar();
$PayController = new PayController($pdo);
$pay= $PayController->listar();
?>