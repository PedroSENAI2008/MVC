<?php   

class PayModel{
    
    private $pdo;



    public function __construct(PDO $pdo){
        $this->pdo = $pdo;

    }

    public function buscarPays(): array{
        $stmt = $this->pdo->query('SELECT * FROM pay');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPay($id): array{
        $stmt = $this->pdo->prepare('SELECT * FROM pay WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function cadastrar($nome, $tipo){
        $sql = 'INSERT INTO pay (nome, tipo) VALUES (:nome, :tipo)';
        $stmt=$this->pdo->prepare($sql);
        $stmt->execute([
            'nome'=>$nome,
             'tipo'=>$tipo
               ]);
    }

    public function editar($id, $nome, $tipo){
        $sql= "UPDATE pay SET nome=?, tipo =? WHERE id=?";
        $stmt=$this->pdo->prepare($sql);
        return $stmt->execute([$nome, $tipo, $id]);
    }
    
    public function deletar($id){
        $sql = "DELETE FROM pay WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute( [$id]);
    }

    
}


?>