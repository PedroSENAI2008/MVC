<?php   

class ProdutoModel{
    
    private $pdo;



    public function __construct(PDO $pdo){
        $this->pdo = $pdo;

    }

    public function buscarTodos(): array{
        $stmt = $this->pdo->query('SELECT * FROM produto');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarProduto($id): array{
        $stmt = $this->pdo->prepare('SELECT * FROM produto WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function cadastrar($nome, $descri, $quant, $code, $preco){
        $sql = ('INSERT INTO produto (nome, descri, quant, code, preco) VALUES (:nome, :descri, :quant, :code, :preco)');
        $stmt=$this->pdo->prepare($sql);
        $stmt->execute([
            'nome'=>$nome,
             'descri'=>$descri,
              'quant'=>$quant,
               'code'=>$code,
                'preco'=>$preco
               ]);
    }

    public function editar($id, $nome, $descri, $quant, $code, $preco){
        $sql= "UPDATE produto SET nome=?, descri=?, quant=?, code=?, preco=? WHERE id=?";
        $stmt=$this->pdo->prepare($sql);
        return $stmt->execute([$nome, $descri, $quant, $code, $preco, $id]);
    }
    
    public function deletar($id){
        $sql = "DELETE FROM produto WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute( [$id]);
    }

    
}


?>