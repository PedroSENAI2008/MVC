<?php
require_once 'DB/Database.php';
require_once 'Controller/ProdutoController.php';
require_once 'Controller/PayController.php';
require_once 'Controller/UsuarioController.php';

$ProdutoController = new ProdutoController($pdo);
$produto= $ProdutoController->listar();
$PayController = new PayController($pdo);
$pay= $PayController->listar();
$UsuarioController = new UsuarioController($pdo);
$usuario = $UsuarioController->listar();
?>