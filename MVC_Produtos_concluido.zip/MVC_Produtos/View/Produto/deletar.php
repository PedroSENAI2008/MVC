<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Controller/ProdutoController.php';

$ProdutoController = new ProdutoController($pdo);

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $produto = $ProdutoController->deletar($id);
   
    header('Location: ../../index.php');
    exit;
} else {
   header('Location: ../../index.php');
}



?>