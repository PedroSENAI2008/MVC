<?php

if (empty($produtos)) {
      echo "<p>Vazio?!</p>";
       echo"<a href='View/Produto/cadastrar.php'>Comprar</a>";
      return;
    }

    echo "<table>";
    echo"<tr ><td>Associados</td>
    <td><a href='View/Produto/cadastrar.php'>Adicionar ao carrinho</a>;
    </tr>";
    echo "<tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Descrição</th>
        <th>Quantidade</th>
        <th>Código de Barras</th>
        <th>Preço(Un.)</th>
        <th>Preço(conjunto)</th>
        <th id='config'>Ações</th>
        
      </tr>";

foreach ($produtos as $produto) {

      $id = $produto['id'];

          $preco_conjunto = $produto['quant'] * $produto['preco'];
      echo "<tr>";
      echo "<td>{$id}</td>";
      echo "<td>{$produto['nome']}</td>";
      echo "<td>{$produto['descri']}</td>";
      echo "<td>{$produto['quant']}</td>";
      echo "<td>{$produto['code']}</td>";
      echo "<td>{$produto['preco']}</td>";
       echo "<td>{$preco_conjunto}</td>";

      echo "<td>
<a class ='edit' href='View/Produto/editar.php?id={$id}'>Editar</a> 
<a class = 'del' href='View/Produto/deletar.php?id={$id}' onclick=\"return confirm('Tem certeza que deseja excluir este usuário?')\">Deletar</a></td>";
      echo "</tr>";
    }

   
  
 echo "</table>";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MVC_teste</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    
</body>
</html>