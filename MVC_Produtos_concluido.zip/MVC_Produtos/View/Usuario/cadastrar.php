<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Controller/UsuarioController.php';
$UsuarioController = new UsuarioController($pdo);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    
    $UsuarioController->cadastrar($nome, $email, $senha);
    header('Location: ../../index.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Usuário</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    
    <form method="POST">
        <h1>Cadastrar Usuário</h1>
        <input type="text" name="nome" placeholder="Nome" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="senha" placeholder="Senha" required><br>

        <button type="submit">Cadastrar</button>

</form>
</body>
</html>