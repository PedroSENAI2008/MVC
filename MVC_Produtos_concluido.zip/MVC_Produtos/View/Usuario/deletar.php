<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Controller/UsuarioController.php';

$UsuarioController = new UsuarioController($pdo);

if (!isset($_GET['id'])) {
    header('Location: ../../index.php');
    exit;
}

$id = $_GET['id'];
$usuario = $UsuarioController->buscarUsuario($id);

if (!$usuario) {
    header('Location: ../../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['confirmar']) && $_POST['confirmar'] == 'sim') {
        $UsuarioController->deletar($id);
    }
    header('Location: ../../index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Usuário</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    <form method="POST">
        <h1>Excluir Usuário</h1>
        <p>Tem certeza que deseja excluir o usuário "<?php echo $usuario['nome']; ?>"?</p>
        
        <input type="hidden" name="confirmar" value="sim">
        <button type="submit">Confirmar Exclusão</button>
        <a href="../../index.php">Cancelar</a>
    </form>
</body>
</html>