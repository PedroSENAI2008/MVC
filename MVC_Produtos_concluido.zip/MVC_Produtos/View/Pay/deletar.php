<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Controller/PayController.php';

$PayController = new PayController($pdo);

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $pay = $PayController->deletarPay($id);
   
    header('Location: ../../index.php');
    exit;
} else {
   header('Location: ../../index.php');
}



?>