<?php

if (empty($pays)) {
      echo "<p>Método de pagamento?!</p>";
       echo"<a href='View/Pay/cadastrar.php'>Método Pagamento</a>";
       
      return;
    }else{
    echo "<table>";
    echo"<tr id='maintr'><td>Associados</td>
    <td> <a href='View/Pay/cadastrar.php'>Método Pagamento</a>;
    </tr>";
    echo "<tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Ações</th>

      </tr>";

foreach ($pays as $pay) {

      $id = $pay['id'];

      echo "<tr>";
      echo "<td>{$id}</td>";
      echo "<td>{$pay['nome']}</td>";
      echo "<td>{$pay['tipo']}</td>";
      

      echo "<td>
<a class ='edit' href='View/Pay/editar.php?id={$id}'>Editar</a> 
<a class = 'del' href='View/Pay/deletar.php?id={$id}' onclick=\"return confirm('Tem certeza que deseja excluir este usuário?')\">Deletar</a></td>";
      echo "</tr>";
    }

   
  
 echo "</table>";
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    
</body>
</html>