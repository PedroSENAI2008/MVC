<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/DB/Database.php';
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Controller/PayController.php';


$PayController = new PayController($pdo);

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $pay = $PayController-> buscarPay($id);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="/MVC_Produtos/style.css">
</head>
<body>
    
      <form method="POST">
      
       
    <form method="POST">
        <h1>Editar pagamento</h1>
        <input type="text" name="nome" placeholder="Nome" required><br>
        <input type="text" name="tipo" placeholder="tipo" required><br>


        <button type="submit">Cadastrar</button>

</form>

</form>
</body>
</html>

<?php
} else {
  header('Location: listar.php');
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  $nome = $_POST['nome'];
  $tipo = $_POST['tipo'];
 


  $PayController->editarPay($id,$nome, $tipo);
  header('Location: ../../index.php ');
}
?>