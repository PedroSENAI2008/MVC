<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Model/PayModel.php';

class PayController{
    private $PayModel;

public function __construct ($pdo){
    $this->PayModel = new PayModel($pdo);
}
 public function listar() {
        $pays = $this->PayModel->buscarPays();
        include_once "C:/Turma1/xampp/htdocs/MVC_Produtos/View/Pay/listar.php";
        return $pays;
    }
    public function buscarPay($id){
        $pay= $this->PayModel->buscarPay($id);
        return $pay;

    }

 public function cadastrarPay($nome, $tipo ){
    return $this->PayModel->cadastrar($nome, $tipo, );
}

public function deletarPay($id){
    $produto = $this->PayModel->deletar($id);

}

public function editarPay($id, $nome, $tipo, ){
    return $this->PayModel->editar($id, $nome, $tipo, );
}
}
?>
