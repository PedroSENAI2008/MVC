<?php
require_once 'C:/Turma1/xampp/htdocs/MVC_Produtos/Model/UsuarioModel.php';

class UsuarioController{
    private $UsuarioModel;

public function __construct ($pdo){
    $this->UsuarioModel = new UsuarioModel($pdo);
}
 public function listar() {
        $usuarios = $this->UsuarioModel->buscarTodos();
        include_once "C:/Turma1/xampp/htdocs/MVC_Produtos/View/Usuario/listar.php";
        return $usuarios;
    }
    public function buscarUsuario($id){
        $usuario = $this->UsuarioModel->buscarUsuario($id);
        return $usuario;

    }

 public function cadastrar($nome, $email, $senha){
    return $this->UsuarioModel->cadastrar($nome, $email, $senha);
}

public function deletar($id){
    $usuario = $this->UsuarioModel->deletar($id);

}

public function editar($id, $nome, $email, $senha){
    return $this->UsuarioModel->editar($id, $nome, $email, $senha);
}

public function autenticar($email, $senha){
    return $this->UsuarioModel->autenticar($email, $senha);
}
}
?>
