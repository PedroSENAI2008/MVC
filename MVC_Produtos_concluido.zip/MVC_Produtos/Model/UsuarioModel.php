<?php   

class UsuarioModel{
    
    private $pdo;

    public function __construct(PDO $pdo){
        $this->pdo = $pdo;
    }

    public function buscarTodos(): array{
        $stmt = $this->pdo->query('SELECT * FROM usuario');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarUsuario($id): array{
        $stmt = $this->pdo->prepare('SELECT * FROM usuario WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function cadastrar($nome, $email, $senha){
        $sql = ('INSERT INTO usuario (nome, email, senha) VALUES (:nome, :email, :senha)');
        $stmt=$this->pdo->prepare($sql);
        $stmt->execute([
            'nome'=>$nome,
            'email'=>$email,
            'senha'=>password_hash($senha, PASSWORD_DEFAULT)
        ]);
    }

    public function editar($id, $nome, $email, $senha){
        $sql= "UPDATE usuario SET nome=?, email=?, senha=? WHERE id=?";
        $stmt=$this->pdo->prepare($sql);
        return $stmt->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), $id]);
    }
    
    public function deletar($id){
        $sql = "DELETE FROM usuario WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }

    public function autenticar($email, $senha){
        $sql = "SELECT * FROM usuario WHERE email = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($usuario && password_verify($senha, $usuario['senha'])) {
            return $usuario;
        }
        
        return false;
    }
}